﻿using MDWebsite.Api_Client;
using MDWebsite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class CustomerDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["type"] != null)
            {
                string usertype = (string)Session["type"];
                if (!usertype.Equals("Customer"))
                {
                    Response.Redirect("default");
                }
                GetPageData();
            }
        }
        private void GetPageData()
        {
            int id = 0;
            if (Session["email"] != null)
            {
               string email = (string)Session["email"];
                User user = new Client().GetUsers().Result.Where(u => u.Email.Equals(email)).FirstOrDefault<User>();
                if(user != null)
                {
                    id = user.Id;
                }
            }
            
            List<Order> orders = new Client().GetUserOrders(id).Result;
            List<Order> pending = orders.Where(o => o.IsCompleted == false).ToList<Order>();
            List<Order> completed = orders.Where(o => o.IsCompleted == true).ToList<Order>();
            if (pending == null) pending = new List<Order>();
            if (completed == null) pending = new List<Order>();
            //update page
            pendingListPlaceHolder.Controls.Clear();
            historyListPlaceHolder.Controls.Clear();
            pendingListPlaceHolder.Controls.Add(new LiteralControl(displayOrders(pending)));
            historyListPlaceHolder.Controls.Add(new LiteralControl(displayOrders(completed)));

        }
        private string displayOrders(List<Order> orders)
        {
            string html = "";
            if(orders.Count == 0)
            {
                return "<h3> No Orders</h3>";
            }
            
            for (int o = 0; o < orders.Count; o++)
            {
                html += "<div class='OrderContainer'>";
                    
                Order order = orders.ElementAt(o);
                string[] items = order.ItemsQuantity.Split('/');
               
                for(int i = 0;i< items.Length;i++)
                {
                    string[] parts = items[i].Split('-');
                    html += "<div class='row text-center' style='width:60%;margin:auto;font-size: larger;font-weight:bold;height: 25px;'>"+ parts[0]
                           + "</div>"
                           + "<div class='row text-center' style='width:60%;margin:auto;font-size: larger;height: 25px;' >" + parts[1]
                           + "</div>";
                           
                }
                html +=  "<div class='row text-right' style='width:60%;margin:auto;font-weight:bold;height: 30px;padding-top: 5px;'>Total R"+ order.Total
                       + "</div>"
                       + "</div>"
                       + "<hr class='underline' />";
            }
            return html;


        }

    }
}