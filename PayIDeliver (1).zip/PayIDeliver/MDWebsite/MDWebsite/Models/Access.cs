﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MDWebsite.Models
{
    public class Access
    {
        public string Email { set; get; }
        public string Password { set; get; }
    }
}