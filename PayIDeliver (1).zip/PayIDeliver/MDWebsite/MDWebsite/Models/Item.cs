﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MDWebsite.Models
{
    public class Item
    {
        public Meat Meat { get; set; }
        public int Quantity { get; set; }
        public double SubTotal { get; set; }
    }
}