﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MDWebsite.Models
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string ItemsQuantity { get; set; }
        public double Total { get; set; }
        public string AddressL1 { get; set; }
        public string AddressL2 { get; set; }
        public string AddressL3 { get; set; }
        public string AddressL4 { get; set; }
        public bool IsCompleted { get; set; }
        public int DriverID { get; set; }
        public int UserId { get; set; }
    }
}