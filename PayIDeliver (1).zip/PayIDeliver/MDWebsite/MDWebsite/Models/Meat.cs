﻿using System;
using System.Linq;
using System.Web;

namespace MDWebsite.Models
{
    public class Meat
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public double Weight { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
        public String Image { get; set; }
    }
}