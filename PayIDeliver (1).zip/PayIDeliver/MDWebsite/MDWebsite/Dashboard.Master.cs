﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class Dashboard : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["type"] != null)
            {
                string html = "";
                string usertype = (string)Session["type"];
                if (usertype.Equals("Admin"))
                {
                    html = "<li><a runat='server' href='Stats'>Statistics</a></li>"
                          +"<hr class='underline'  style='color:whitesmoke;width: 100%;'/>"
                           +"<li><a runat='server' href='Products'>Products</a></li>"
                           +"<hr class='underline'  style='color:whitesmoke;width: 100%;'/>";

                }
                else if (usertype.Equals("Driver"))
                {
                    html = "<hr class='underline'  style='color:whitesmoke;width: 100%;'/>"
                        + "<li><a runat='server' href='DriverDashboard'>Dashboard</a></li>"
                        + "<hr class='underline'  style='color:whitesmoke;width: 100%;'/>";
                }
                else if (usertype.Equals("Customer"))
                {
                    html = "<hr class='underline'  style='color:whitesmoke;width: 100%;'/>"
                        + "<li><a runat='server' href='CustomerDashboard'>Dashboard</a></li>"
                        + "<hr class='underline'  style='color:whitesmoke;width: 100%;'/>";
                }
                this.mobilelinksPlaceHolder.Controls.Clear();
                this.weblinksPlaceHolder.Controls.Clear();
                this.mobilelinksPlaceHolder.Controls.Add(new LiteralControl(html));
                this.weblinksPlaceHolder.Controls.Add(new LiteralControl(html));
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }
    }
}