﻿using MDWebsite.Api_Client;
using MDWebsite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class _Default : Page, IPostBackEventHandler                 
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["cart"] = null;
            if (!IsPostBack)
            {
                string category = categoryList.SelectedItem.Text;
                updatePage(getProducts(category));
            }
        }
        protected void categoryList_SelectedIndexChanged(object sender, EventArgs e)
        {
            string category = categoryList.SelectedItem.Text;
            updatePage(getProducts(category));
        }
        private List<Meat> getProducts(string category)
        {
            List<Meat> meatList = new Client().GetProducts(category).Result;
            if (category.Equals("All"))
            {
                meatList = new Client().GetProducts().Result;
            }
            else
            {
                meatList = new Client().GetProducts(category).Result;
            }
            return meatList;
        }
        private string getProductsHtml(List<Meat> products)
        {
            string html = "";
            string category = categoryList.SelectedItem.Text;
            List<int> cartList = (List<int>)Session["cartItems"];
            if (cartList == null)
            {
                cartList = new List<int>();
            }
            for (int i = 0; i < products.Count; i++)
            {
                Meat product = products.ElementAt(i);
                string fullname = "";
                if (category.Equals("All"))
                {
                    fullname = "(" + product.Category + ")";
                }
                string buttonHtml = "";
                string label = "";
                if (cartList.Contains(product.Id))//then add button to remove product from list
                {
                    buttonHtml = "remove(" + product.Id + ")";
                    label = "Remove from cart";
                }
                else
                {
                    buttonHtml = "add(" + product.Id + ")";
                    label = "Add to cart";
                }
                html += "<div class='col-sm-3' style='min-width: 200px;margin-left:4% !important;margin-right:4% !important; border: 3.5px solid;border-color: #929fba;box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19); border-radius: 10px; padding: 10px; margin: 1vh;color:#404e6b'>"
                    + "<div style='width:fit-content;margin:auto;'><img src='" + product.Image + "' class='img-rounded' alt='' style='width:260px;height:150px;'></div>"
                       + "<div class='HeadLabel'>" + product.Name + " "+ fullname + "</div>"
                    + "<div class='WeightLabel'>" + product.Weight + "<span />Kg</div>"
                    + "<hr class='underline' />"
                    + "<div class='lineContainer'>"
                        + "<div class='leftLabel'>Price</div>"
                        + "<div class='rightLabel'>R<span />" + product.Price + "</div>"
                    + "</div>"
                    + "<hr class='underline' />"
                    + "<div class='lineContainer'>"
                        + "<div class='leftLabel'>Quantity</div>"
                        + "<div class='rightLabel'><span />" + product.Quantity + "</div>"
                    + "</div>"
                       + "<div style='display:flex;justify-content:center'><button type='button' class='btn' onClick="+ buttonHtml + " style='min-width:13vh;width:fit-content;background:#929fba;color:whitesmoke;margin-top:1vh;'>"+ label + "</button></div>"
                 + "</div>";
            }
            return html;
        }
        private void updatePage(List<Meat> products)
        {
            string productsHtml = "";
            if (products.Count > 0)
            {
                productsHtml = getProductsHtml(products);
            }
            else
            {
                productsHtml = "<div class='col-sm-8' ><H3> No Products available</h3></div>";
            }
            this.productsPlaceholder.Controls.Add(new LiteralControl(productsHtml));
        }

        public void RaisePostBackEvent(string eventArgument)
        {
            if (eventArgument.Contains("add"))
            {
                addToCart(eventArgument.Split(' ')[1]);
            }
            else
            {
                removeFromCart(eventArgument.Split(' ')[1]);
            }
            Response.Redirect("Default.aspx");
        }
        private void addToCart(string strID)
        {
            int id = int.Parse(strID);
            List<int> list = (List<int>)Session["cartItems"];
            if(!list.Contains(id))
            {
                list.Add(id);
                Session["cartItems"] = list;
            }
        }
        private void removeFromCart(string strID)
        {
            int id = int.Parse(strID);
            List<int> list = (List<int>)Session["cartItems"];
            if (list.Contains(id))
            {
                list.Remove(id);
                Session["cartItems"] = list;
            }
        }
    }
}