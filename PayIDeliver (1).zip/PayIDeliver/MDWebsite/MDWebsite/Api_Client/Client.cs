﻿using MDWebsite.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace MDWebsite.Api_Client
{
    public class Client
    {
        private HttpClient client;
        //constructor
        public Client()
        {
            //WebService address(url) : 
            string url = "https://localhost:44308/";
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }



        //Webservice calls

        public async Task<User> GetUser(int id)
        {
            //GET /api/Service/GetUsers
            User user = null;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Users/GetUser?id="+id).Result;
            if (response.IsSuccessStatusCode)
            {
                user = (User)await response.Content.ReadAsAsync<User>();

            }
            return user;
        }
        public async Task<List<User>> GetUsers()
        {
            //GET /api/Service/GetUsers
            List<User> users = new List<User>();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Users/GetUsers").Result;
            if (response.IsSuccessStatusCode)
            {
                users = (List<User>)await response.Content.ReadAsAsync<IEnumerable<User>>();

            }
            return users.ToList();
        }
        public async Task<List<Meat>> GetProducts(string category)
        {
            //GET /api/Service/GetUsers
            List<Meat> products = new List<Meat>();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Meats/GetMeatsByCategory?category=" + category).Result;
            if (response.IsSuccessStatusCode)
            {
                products = (List<Meat>)await response.Content.ReadAsAsync<IEnumerable<Meat>>();

            }
            return products.ToList();
        }
        public async Task<List<Meat>> GetProductsByIds(List<int> ids)
        {
            List<Meat> products = new List<Meat>();
            //GET /api/Users/AddUser
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //HttpContent rcontent = null;
            var jObject = JsonConvert.SerializeObject(ids);
            var stringContent = new StringContent(jObject, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync("/api/Meats/GetMeatsByIds", stringContent).Result;
            if (response.IsSuccessStatusCode)
            {
                HttpContent content = response.Content;

                products = await content.ReadAsAsync<List<Meat>>();
            }
            return products;
        }
        public async Task<List<Meat>> GetProducts()
        {
            //GET /api/Service/GetUsers
            List<Meat> products = new List<Meat>();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Meats/GetMeats").Result;
            if (response.IsSuccessStatusCode)
            {
                products = (List<Meat>)await response.Content.ReadAsAsync<IEnumerable<Meat>>();

            }
            return products.ToList();
        }
        public async Task<Meat> GetProduct(int id)
        {
            //GET /api/Service/GetUsers
            Meat product = null;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Meats/GetMeat?id="+id).Result;
            if (response.IsSuccessStatusCode)
            {
                product = await response.Content.ReadAsAsync<Meat>();

            }
            return product;
        }
        public async Task<bool> Login(Access access)
        {
            //GET /api/Users/GetUsers
            bool logged = false;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //HttpContent rcontent = null;
            var jObject = JsonConvert.SerializeObject(access);
            var stringContent = new StringContent(jObject, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync("/api/Services/Login", stringContent).Result;
            if (response.IsSuccessStatusCode)
            {
                HttpContent content = response.Content;

                logged = await content.ReadAsAsync<bool>();
            }
            return logged;
        }
        public async Task<User> AddUser(User user)
        {
            User dbUser = null;
            //GET /api/Users/AddUser
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //HttpContent rcontent = null;
            var jObject = JsonConvert.SerializeObject(user);
            var stringContent = new StringContent(jObject, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync("/api/Users/AddUser", stringContent).Result;
            if (response.IsSuccessStatusCode)
            {
                HttpContent content = response.Content;

                dbUser = await content.ReadAsAsync<User>();
            }
            return dbUser;
        }
        public async Task<Meat> AddProduct(Meat product)
        {
            Meat dbMeat = null;
            //GET /api/Users/AddUser
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //HttpContent rcontent = null;
            var jObject = JsonConvert.SerializeObject(product);
            var stringContent = new StringContent(jObject, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync("/api/Meats/AddMeat", stringContent).Result;
            if (response.IsSuccessStatusCode)
            {
                HttpContent content = response.Content;

                dbMeat = await content.ReadAsAsync<Meat>();
            }
            return dbMeat;
        }
        public async Task<Meat> DeleteProduct(int id)
        {
            Meat dbMeat = null;
            //GET /api/Service/GetUsers
            Meat product = null;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.DeleteAsync("/api/Meats/DeleteMeat?id=" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                product = await response.Content.ReadAsAsync<Meat>();

            }
            return product;
        }
        public async Task<Meat> UpdateProduct(Meat product)
        {
            Meat dbMeat = null;
            //GET /api/Users/AddUser
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //HttpContent rcontent = null;
            var jObject = JsonConvert.SerializeObject(product);
            var stringContent = new StringContent(jObject, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync("/api/Meats/UpdateMeat", stringContent).Result;
            if (response.IsSuccessStatusCode)
            {
                HttpContent content = response.Content;

                dbMeat = await content.ReadAsAsync<Meat>();
            }
            return dbMeat;
        }
        public async Task<Order> AddOrder(Order userOrder)
        {
            Order dbOrder = null;
            //GET /api/Users/AddUser
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //HttpContent rcontent = null;
            var jObject = JsonConvert.SerializeObject(userOrder);
            var stringContent = new StringContent(jObject, UnicodeEncoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync("/api/Orders/AddOrder", stringContent).Result;
            if (response.IsSuccessStatusCode)
            {
                HttpContent content = response.Content;

                dbOrder = await content.ReadAsAsync<Order>();
            }
            return dbOrder;
        }
        public async Task<List<Order>> GetOrders()
        {
            //GET /api/Service/GetUsers
            List<Order> orders = new List<Order>();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Orders/GetOrders").Result;
            if (response.IsSuccessStatusCode)
            {
                orders = (List<Order>)await response.Content.ReadAsAsync<IEnumerable<Order>>();

            }
            return orders.ToList();
        }
        public async Task<List<Order>> GetUserOrders(int id)
        {
            //GET /api/Service/GetUsers
            List<Order> orders = new List<Order>();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Orders/GetUserOrders?userId=" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                orders = (List<Order>)await response.Content.ReadAsAsync<IEnumerable<Order>>();

            }
            return orders.ToList();
        }
        public async Task<List<Order>> GetPendingOrders()
        {
            //GET /api/Service/GetUsers
            List<Order> orders = new List<Order>();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Orders/GetOrders").Result;
            if (response.IsSuccessStatusCode)
            {
                orders = (List<Order>)await response.Content.ReadAsAsync<IEnumerable<Order>>();
            }
            return orders.ToList();
        }
        public async Task<Order> GetOrder(int id)
        {
            //GET /api/Service/GetUsers
            Order order = null;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Orders/GetOrder?id=" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                order = await response.Content.ReadAsAsync<Order>();

            }
            return order;
        }
        public async Task<int> AssignOrder(string email,int orderId)
        {
            //GET /api/Service/GetUsers
            int status = 0;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Orders/AssignOrder?email="+email+"&orderId=" + orderId).Result;
            if (response.IsSuccessStatusCode)
            {
                status = await response.Content.ReadAsAsync<int>();

            }
            return status;
        }
        public async Task<int> UpdateType(string email, string type)
        {
            //GET /api/Service/GetUsers
            int status = 0;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Services/UpdateType?email=" + email + "&type=" + type).Result;
            if (response.IsSuccessStatusCode)
            {
                status = await response.Content.ReadAsAsync<int>();

            }
            return status;
        }
        public async Task<int> UnAssignOrder(int orderId)
        {
            //GET /api/Service/GetUsers
            int status = 0;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Orders/UnAssignOrder?id=" + orderId).Result;
            if (response.IsSuccessStatusCode)
            {
                status = await response.Content.ReadAsAsync<int>();

            }
            return status;
        }
        public async Task<int> CompleteOrder(int id)
        {
            //GET /api/Service/GetUsers
            int status = 0;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("/api/Orders/CompleteOrder?id=" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                status = await response.Content.ReadAsAsync<int>();

            }
            return status;
        }

    }
}