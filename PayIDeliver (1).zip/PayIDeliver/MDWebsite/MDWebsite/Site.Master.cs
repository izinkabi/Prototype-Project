﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class SiteMaster : MasterPage
    {
        protected List<int> cartItems;
        protected void Page_Load(object sender, EventArgs e)
        {
            validateNavBar();
            updateCartItems();

        }
        public void updateCartItems()
        {
            if (Session["cartItems"] != null)
            {
                cartItems = (List<int>)Session["cartItems"];
            }
            else
            {
                cartItems = new List<int>();
                Session["cartItems"] = cartItems;
            }
            lblCartCount.Text = "" + cartItems.Count;
        }
        private void validateNavBar()
        {
            string html = "";
            if(Session["email"] != null)
            {
                string username = (string)Session["email"];
                
                html = "<li><a runat='server' href='Login'>Sign Out</a></li>"
                      +"<li><a runat='server' href='Account'>"+ username + "</a></li>";
                /*html = "<li class='nav - item dropdown'>"
                          +"<a class='nav-link dropdown-toggle' href='Account' id='navbarDropdownMenuLink' role='button'data-toggle='ropdown' aria-haspopup='true' aria-expanded='false'>"+ username
                          + "</a>"
                          +"<div class='dropdown-menu' aria-labelledby='navbarDropdownMenuLink'>"
                              +"<a class='dropdown-item' href='Login'>Sign out</a>"
                          + "</div>"
                       + "</li>"; */
                string html2 = "<li><a runat='server' href='CustomerDashboard'>Dashboard</a></li>";
               if(Session["type"] != null)
                {
                    string usertype = (string)Session["type"];
                    if (usertype.Equals("Admin"))
                    {
                        html2 = "<li><a runat='server' href='Stats'>Dashboard</a></li>";
                    }else if (usertype.Equals("Driver"))
                    {
                        html2 = "<li><a runat='server' href='DriverDashboard'>Dashboard</a></li>";
                    }
                    this.adminLinkPlaceholder.Controls.Add(new LiteralControl(html2));
                }
            }
            else
            {
                html ="<li><a runat='server' href='Login'>Sign in</a></li>";
            }
            this.LoginPlaceholder.Controls.Add(new LiteralControl(html));
        }
    }
}