﻿using MDWebsite.Api_Client;
using MDWebsite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class Cart : System.Web.UI.Page, IPostBackEventHandler
    {
        CartBP cart;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["cart"] == null)
            {
                if (Session["cartItems"] != null && Session["email"] != null)
                {
                    List<int> Ids = (List<int>)Session["cartItems"];
                    List<Meat> products = new Client().GetProductsByIds(Ids).Result;
                    User user = new Client().GetUsers().Result.Where(u => u.Email.Equals((string)Session["email"])).FirstOrDefault<User>();
                    
                    cart = new CartBP(products,user);
                    Session["cart"] = cart;

                    //update page
                    updatePage();
                }
                else
                {
                    Response.Redirect("default.aspx");
                }
            }
            else
            {
                cart = (CartBP)Session["cart"];

                //update page
                updatePage();
            }
        }
        private void updatePage()
        {
            if(this.cart == null)
            {
                return;
            }
            this.CartItemsPlaceHolder.Controls.Clear();
            this.CartItemsPlaceHolder.Controls.Add(new LiteralControl(itemsHtml()));
            lblTotal.Text = "Total: R" + this.cart.Total;
        }
        private string itemsHtml()
        {
            string html = "";
            List<Item> items = this.cart.Items;
            if(items.Count == 0)
            {
                return "<h3> No items</h3>";
            }
            for(int i = 0; i < items.Count; i++)
            {
                Item item = items.ElementAt(i);

                html += "<div class='row'>"
                     +"<div class='col-sm-6'>"
                     + "<div class='infor' style='width: 200px;height: 100px;padding: 10px;'>"
                     + "<div class='leftTop' style='display: flex;height: 30px;width:100%;justify-content: center;'><strong>"+item.Meat.Category+"</strong></div>"
                     + "<div class='leftMid' style='display: flex;height: 30px;width:100%;justify-content: center;'>"+item.Meat.Name+"</div>"
                     + "<div class='leftBottom' style='display: flex;height: 30px;width:100%;justify-content: center;'>"+item.Meat.Weight+"(KG)</div>"
                     + "</div>"
                     + "</div>"
                     + "<div class='col-sm-6'>"
                     + "<div class='counts' style='width: 200px;height: 100px;padding: 10px;padding-top: 25px;'>"
                     + "<div class='leftTop' style='display: flex;height:fit-content;width:100%;text-align:left;'>"
                     + "<div style='width: 100px;display: flex;justify-content: flex-end;padding-top: 9px; padding-right: 10px;'>Quantity:</div>"
                     + "<div style='width: 10px;display: flex;justify-content: flex-end;padding-top: 9px; padding-right: 10px;'>"+item.Quantity+"</div>"
                     + "<button type='button' class='btn btn-info' onClick=dowork('update',"+item.Meat.Id+") style='width: 60px;background-color: #929fba;'>Edit</button>"
                     + "<button type='button' class='btn btn-danger' onClick=dowork('remove'," + item.Meat.Id + ") style='width: 70px;margin-left:5px;'>Remove</button>"
                     + "</div>"
                     + "<hr class='underline' style='margin: 5px;'/>"
                     + "<div class='leftBottom' style='display: flex;height: 30px;width:100%;text-align:left;'><div style='width: 65px;'>Total(R):</div><div>"+item.SubTotal+"</div> </div>"
                     + "<hr class='underline' style='margin: 5px;'/>"
                     + "</div>"
                     + "</div>"
                     + "</div>";
                if (i != items.Count - 1)
                {
                    html += "<div class='row'>"
                              + "<hr class='underline' />"
                           +"</div>";
                }

            }
            return html;
        }

        public void RaisePostBackEvent(string eventArgument)
        {
            string[] args = eventArgument.Split(':');
            if (args[0].Equals("remove"))
            {
                if(Session["cart"] != null)
                {
                    this.cart = (CartBP)Session["cart"];
                    int id = int.Parse(args[1]);
                    this.cart.Remove(id);
                    this.cart.recalculateTotalAmount();
                    List<int> Ids = (List<int>)Session["cartItems"];
                    Ids.Remove(id);
                    Session["cartItems"] = Ids;
                    Session["cart"] = this.cart;
                }
                Response.Redirect("Cart.aspx");
            }
            else if(args[0].Equals("update"))//update
            {
                if (Session["cart"] != null)
                {
                    this.cart = (CartBP)Session["cart"];
                    if(this.cart.Update(int.Parse(args[1]), int.Parse(args[2])))
                    {
                        this.cart.recalculateTotalAmount();
                        Session["cart"] = this.cart;
                    }
                    else
                    {
                       //alert
                    }
                }
                Response.Redirect("Cart.aspx");
            }else if (args[0].Equals("checkout"))
            {
                List<int> ids = (List<int>)Session["cartItems"];
                if(ids.Count <= 0)
                {
                    lblresponse.Text = "no items in your cart";
                    return;
                }
                if(AddressLine1.Value.ToString().Length <= 0 || AddressLine2.Value.ToString().Length <= 0 || AddressLine3.Value.ToString().Length <= 0){
                    lblresponse.Text = "Address line 1,2 and 3 cannot be empty";
                    return;
                }
                this.cart = (CartBP)Session["cart"];
                this.cart.setFullAddres(AddressLine1.Value.ToString(), AddressLine2.Value.ToString(), AddressLine3.Value.ToString(), AddressLine4.Value.ToString());
                Session["cart"] = this.cart;
                Order dbOrder = new Client().AddOrder(this.cart.GetUserOrder()).Result;
                if(dbOrder != null)
                {
                    List<int> cartItems = new List<int>();
                    Session["cartItems"] = cartItems;
                    Session["cart"] = null;
                    Response.Redirect("CustomerDashboard.aspx");
                }
                else
                {
                    lblresponse.Text = "failed to checkout order, an unexpected error occured";
                }
                
            }
        }
    }
}