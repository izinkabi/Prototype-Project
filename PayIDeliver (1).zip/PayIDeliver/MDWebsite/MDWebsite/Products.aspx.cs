﻿using MDWebsite.Api_Client;
using MDWebsite.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class Products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string category = categoryList.SelectedItem.Text;
                updatePage(category, getProducts(category));
            }
        }

        protected void BtnAdd_Click(object sender, EventArgs e)
        {
            string validation = validateAddProductForm();
            if (validation.Equals("pass"))
            {
                Meat meatProduct = new Meat()
                {
                    Name = pName.Value.ToString(),
                    Category = lblCategory.Text.ToString(),
                    Weight = double.Parse(pWeight.Value.ToString().Replace('.', ',')),
                    Price = double.Parse(pPrice.Value.ToString().Replace('.', ',')),
                    Quantity = int.Parse(pQuantity.Value.ToString()),
                    Image = (String)Session["image"]
                };
                Meat dbMeat = new Client().AddProduct(meatProduct).Result;
                if(dbMeat != null)
                {

                    string category = categoryList.SelectedItem.Text;
                    updatePage(category, getProducts(category));

                    lblAResponse.Text = dbMeat.Name + " Added successfully";
                }
                else
                {
                    lblAResponse.Text = "An Unexpected error occured, request failed";
                }

            }
            else
            {
                lblAResponse.Text = validation;
            }
        }
        protected void categoryList_SelectedIndexChanged(object sender, EventArgs e)
        {
            string category = categoryList.SelectedItem.Text;
            updatePage(category, getProducts(category));
        }
        private List<Meat> getProducts(string category)
        {
            List<Meat> meatList = new Client().GetProducts(category).Result;
            return meatList;
        }
        private void updatePage(string category, List<Meat> products)
        {
            lblCategory.Text = category;
            string productsHtml = "";
            if (products.Count > 0)
            {
                productsHtml = getProductsHtml(products);
            }
            else
            {
                productsHtml = "<div class='col-sm-8' ><H3> No Products available in " + category + " category</h3></div>";
            }
            this.productsPlaceHolder.Controls.Add(new LiteralControl(productsHtml));
        }
        private string getProductsHtml(List<Meat> products)
        {
            string html = "";
            for(int i = 0; i < products.Count; i++)
            {
                Meat product = products.ElementAt(i);
                html += "<div class='col-sm-3' style='min-width: 200px; border: 3.5px solid;border-color: #929fba;box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19); border-radius: 10px; padding: 10px; margin: 1vh;'>"
                    + "<div style='width:fit-content;margin:auto;'><img src='" + product.Image + "' class='img-rounded' alt='' style='width:200px;height:150px;'></div>"
                    + "<div class='HeadLabel'>"+product.Name+"</div>"
                    + "<div class='WeightLabel'>"+ product.Weight+ "<span />Kg</div>"
                    + "<hr class='underline' />"
                    + "<div class='lineContainer'>"
                        + "<div class='leftLabel'>Price</div>"
                        + "<div class='rightLabel'>R<span />" + product.Price + "</div>"
                    + "</div>"
                    + "<hr class='underline' />"
                    + "<div class='lineContainer'>"
                        + "<div class='leftLabel'>Quantity</div>"
                        + "<div class='rightLabel'><span />" + product.Quantity + "</div>"
                    + "</div>"
                       + "<div style='display:flex;justify-content:center;'><button type='button' class='btn' onClick=gotToProductId("+ product.Id+ ") style='width:13vh;background:#929fba;color:whitesmoke;margin-top:1vh;'>Modify</button></div>"
                 + "</div>";
            }
            return html;
        }
        private string validateAddProductForm()
        {
            string results = "";
            if(pName.Value.ToString().Length <= 0)
            {
                return "please enter product name";
            }
            if (double.Parse(pWeight.Value.ToString().Replace('.',',')) <= 0)
            {
                return "product weight must be greater than 0";
            }
            if (double.Parse(pPrice.Value.ToString().Replace('.', ',')) <= 0)
            {
                return "product price must be greater than 0";
            }
            if (int.Parse(pQuantity.Value.ToString()) < 0)
            {
                return "product price must be a positive number";
            }
            if(Session["image"] == null)
            {
                return "please upload product image";
            }

            return "pass";
        }

        protected void UploadButton_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                try
                {
                    if (FileUpload1.PostedFile.ContentType == "image/jpeg")
                    {

                        int iLen = FileUpload1.PostedFile.ContentLength;
                        byte[] btArr = new byte[iLen];
                        FileUpload1.PostedFile.InputStream.Read(btArr, 0, iLen);
                        String b64Image = Convert.ToBase64String(btArr);

                        string src = "data:image/jpeg;base64," + b64Image;
                        Session["image"] = src;
                        imgView.ImageUrl = src;
                        lblAResponse.Text = "Upload status: File uploaded!";
                        
                    }
                    else
                        lblAResponse.Text = "Upload status: Only JPEG files are accepted!";
                }
                catch (Exception ex)
                {
                    lblAResponse.Text = "Upload status: The file could not be uploaded. The following error occured: " + ex.Message;
                }
            }
        }
    }
}