﻿using MDWebsite.Api_Client;
using MDWebsite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class DriverDashboard : Page ,IPostBackEventHandler
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["type"] != null)
            {
                string usertype = (string)Session["type"];
                if (!usertype.Equals("Driver"))
                {
                    Response.Redirect("default");
                }
                GetPageData();
            }
            else
            {
                Response.Redirect("default");
            }
        }
        private void GetPageData()
        {
            int id = 0;
            if (Session["email"] != null)
            {
                string email = (string)Session["email"];
                User user = new Client().GetUsers().Result.Where(u => u.Email.Equals(email)).FirstOrDefault<User>();
                if (user != null)
                {
                    id = user.Id;
                }
            }

            List<Order> pendingOrders = new Client().GetPendingOrders().Result;
            List<Order> pDelivery = pendingOrders.Where(o => o.IsCompleted == false && o.DriverID >0 && o.DriverID == id).ToList<Order>();
            List<Order> pAssign = pendingOrders.Where(o => o.IsCompleted == false && o.DriverID == 0).ToList<Order>();
            if (pDelivery == null) pDelivery = new List<Order>();
            if (pAssign == null) pAssign = new List<Order>();
            //update page
            scheduleListPlaceHolder.Controls.Clear();
            unasignedListPlaceHolder.Controls.Clear();
            scheduleListPlaceHolder.Controls.Add(new LiteralControl(displayDelivery(pDelivery)));
            unasignedListPlaceHolder.Controls.Add(new LiteralControl(displayAssign(pAssign)));

        }
        private string displayDelivery(List<Order> orders)
        {
            string html = "";
            if (orders.Count == 0)
            {
                return "<h3> No Orders</h3>";
            }
            List<User> users = new Client().GetUsers().Result;
            for (int o = 0; o < orders.Count; o++)
            {

                html += "<div class='OrderContainer'>";

                Order order = orders.ElementAt(o);
                User user = users.Where(u => u.Id == order.UserId).FirstOrDefault<User>();
                string cell = "Cell : N/A";
                if(user != null)
                {
                    cell = "+27" + user.Phone;
                }
                string[] items = order.ItemsQuantity.Split('/');

                for (int i = 0; i < items.Length; i++)
                {
                    string[] parts = items[i].Split('-');
                    html += "<div class='row text-center' style='width:60%;margin:auto;font-size: larger;font-weight:bold;height: 25px;'>" + parts[0]
                           + "</div>"
                           + "<div class='row text-center' style='width:60%;margin:auto;font-size: larger;height: 25px;' >" + parts[1]
                           + "</div>";

                }
                html += "<div class='row text-right' style='width:60%;margin:auto;font-weight:bold;font-size: larger;height: 30px;padding-top: 5px;'>Total R" + order.Total
                         + "</div>"
                    + "<div class='row text-right' style='width:60%;margin:auto;font-weight:bold;font-size: larger;height: 30px;padding-top: 5px;'>Address"
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;height: 30px;padding-top: 5px;'>" + order.AddressL1
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;height: 30px;padding-top: 5px;'>" + order.AddressL2
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;height: 30px;padding-top: 5px;'>" + order.AddressL3
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;height: 30px;padding-top: 5px;'>" + cell
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;font-weight:bold;display:flex;justify-content:right;'>"
                       + "<button type='button' class='btn btn-danger' onClick=dowork('unassign'," + order.Id + ") style='margin:auto;width: 130px;'>Unassign</button><button type='button' class='btn btn-success' onClick=dowork('complete'," + order.Id + ") style='margin:auto;width: 130px;'>Complete Delivery</button>"
                       + "</div>"
                       + "</div>"
                       + "<hr class='underline' />";
            }
            return html;
        }
        private string displayAssign(List<Order> orders)
        {
            string html = "";
            if (orders.Count == 0)
            {
                return "<h3> No Orders</h3>";
            }
            List<User> users = new Client().GetUsers().Result;
            for (int o = 0; o < orders.Count; o++)
            {
                html += "<div class='OrderContainer'>";

                Order order = orders.ElementAt(o);
                User user = users.Where(u => u.Id == order.UserId).FirstOrDefault<User>();
                string cell = "Cell : N/A";
                if (user != null)
                {
                    cell = "+27" + user.Phone;
                }
                string[] items = order.ItemsQuantity.Split('/');

                for (int i = 0; i < items.Length; i++)
                {
                    string[] parts = items[i].Split('-');
                    html += "<div class='row text-center' style='width:60%;margin:auto;font-size: larger;font-weight:bold;height: 25px;'>" + parts[0]
                           + "</div>"
                           + "<div class='row text-center' style='width:60%;margin:auto;font-size: larger;height: 25px;' >" + parts[1]
                           + "</div>";

                }
                html += "<div class='row text-right' style='width:60%;margin:auto;font-weight:bold;font-size: larger;height: 30px;padding-top: 5px;'>Total R" + order.Total
                         + "</div>"
                    + "<div class='row text-right' style='width:60%;margin:auto;font-weight:bold;font-size: larger;height: 30px;padding-top: 5px;'>Address"
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;height: 30px;padding-top: 5px;'>" + order.AddressL1
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;height: 30px;padding-top: 5px;'>" + order.AddressL2
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;height: 30px;padding-top: 5px;'>" + order.AddressL3
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;height: 30px;padding-top: 5px;'>" + cell
                       + "</div>"
                       + "<div class='row text-right' style='width:60%;margin:auto;font-weight:bold;display:flex;justify-content:right;'>"
                       +"<button type='button' class='btn btn-success' onClick=dowork('assign',"+order.Id+ ") style='margin:auto;width: 130px;'>Add to Schedule</button>"
                       + "</div>"
                       + "</div>"
                       + "<hr class='underline' />";
            }
            return html;
        }
        public void RaisePostBackEvent(string eventArgument)
        {
            string[] args = eventArgument.Split(' ');
            int id = int.Parse(args[1]);
            if (args[0].Equals("assign"))
            {
                string email = (string)Session["email"];
                int status = new Client().AssignOrder(email, id).Result;
                if(status == 1)
                {
                    Response.Redirect("DriverDashboard.aspx");
                }
                else
                {

                }
            }else if (args[0].Equals("unassign"))
            {
                int status = new Client().UnAssignOrder(id).Result;
                if (status == 1)
                {
                    Response.Redirect("DriverDashboard.aspx");
                }
                else
                {

                }
            }
            else if (args[0].Equals("complete"))
            {
                int status = new Client().CompleteOrder(id).Result;
                if (status == 1)
                {
                    Response.Redirect("DriverDashboard.aspx");
                }
                else
                {

                }
            }
        }
    }
}