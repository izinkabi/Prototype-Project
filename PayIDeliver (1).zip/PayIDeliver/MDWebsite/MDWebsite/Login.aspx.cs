﻿using MDWebsite.Api_Client;
using MDWebsite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["email"] != null)
            {
                Session["email"] = null;
            }
            Session["cartItems"] = null;
            Session["type"] = null;
        }

        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            string userEmail = email.Value.ToString();
            string userPassword = password.Value.ToString();
            if (userEmail.Length > 0 && userEmail.Contains("@") && userPassword.Length>0)
            {
                Access access = new Access()
                {
                    Email = userEmail,
                    Password = userPassword
                };
                bool validLogin = new Client().Login(access).Result;
                if (validLogin)
                {
                    User dbUser = new Client().GetUsers().Result.Where(u => u.Email.Equals(access.Email)).FirstOrDefault<User>();
                    if(dbUser != null)
                    {
                        Session["email"] = access.Email;
                        Session["type"] = dbUser.Type;
                        Response.Redirect("Default.aspx");
                    }
                    else
                    {
                        lblLResponse.Text = "email and password do not match";
                    }
                }
                else
                {
                    lblLResponse.Text = "email and password do not match";
                }
            }
            else
            {
                lblLResponse.Text = "please enter valid login details";
            }
        }

        protected void BtnRegister_Click(object sender, EventArgs e)
        {
            string userEmail = email2.Value.ToString();
            string userPassword = password2.Value.ToString();
            string userCPassword = confirmpassword.Value.ToString();
            long userPhone = 0;
            bool isValidForm = true;
            if(userEmail.Length <= 0 && !userEmail.Contains("@")){
                isValidForm = false;
                lblRResponse.Text = "invalid email address, missing '@'";
                return;
            }
            if (userPassword.Length <= 0)
            {
                isValidForm = false;
                lblRResponse.Text = "passwords do not match";
                return;
            }
            if (!userPassword.Equals(userCPassword))
            {
                isValidForm = false;
                lblRResponse.Text = "please enter password";
                return;
            }
            try
            {
                string strNum = phoneNumber.Value.ToString();
                if(strNum.Length != 10)
                {
                    throw new Exception("number must be 10 digits");
                }else if (!strNum.StartsWith("0"))
                {
                    throw new Exception("number must start with '0'");
                }
                userPhone = long.Parse(strNum);
            }
            catch(Exception ex)
            {
                ex.GetBaseException();
                lblRResponse.Text = "invalid phone number: "+ex.Message;
                isValidForm = false;
            }
            if (isValidForm)
            {
                User user = new User()
                {
                   Email = userEmail,
                   Password = userPassword,
                   Type = "Customer",
                   Phone = userPhone,
                   IsActive = true
                };
                User dbUser = new Client().AddUser(user).Result;
                if(dbUser != null)
                {
                    Session["email"] = dbUser.Email;
                    Session["type"] = dbUser.Type;
                    Response.Redirect("Default.aspx");
                }
            }
        }
    }
}