﻿using MDWebsite.Api_Client;
using MDWebsite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class Stats : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UpdatePage();
        }
        private void UpdatePage()
        {
            List<Order> orders = new Client().GetOrders().Result;
            List<User> users = new Client().GetUsers().Result;

            userlistPH.Controls.Clear();
            orderslistPH.Controls.Clear();
            orderslistPH.Controls.Add(new LiteralControl(getOrdersStats(orders)));
            userlistPH.Controls.Add(new LiteralControl(getUsersStats(users)));

        }
        private string getOrdersStats(List<Order> orders)
        {
            string html = "";
            double newO = orders.Where(u => u.IsCompleted == false && u.DriverID == 0).ToList<Order>().Count;
            double pendindD = orders.Where(u => u.IsCompleted == false && u.DriverID >0).ToList<Order>().Count;
            double completedO = orders.Where(u => u.IsCompleted == true && u.DriverID > 0).ToList<Order>().Count;
            double total = orders.Count;
            html += "<div class='col-sm-3 Center-Stats-Col'>"
                + "<div class='card'>"
                 + "<div class='card-img-top'>"
                    + "<div class='alignImage' style='width: 120px;height: 120px;margin: auto;margin-top:1vh;'>"
                      + "<div class='c100 " + toCssAmount((int)((newO / total) * 100)) + "'>"
                       + "<span>" + ((int)((newO / total) * 100)) + "%</span>"
                        + "<div class='slice'>"
                          + "<div class='bar'></div>"
                          + "<div class='fill'></div>"
                        + "</div>"
                      + "</div>"
                    + "</div>"
                 + "</div>"
                 + "<div class='card-title' style='width:fit-content;margin:auto;font-weight: bolder;'>New </div>"
                  + "<div class='card-body'>"
                    + "<p class='card-text' style='text-align: center;'>" + newO+ "<span />/" + total + "</p>"
                  + "</div>"
                + "</div>"
              + "</div>";


            html += "<div class='col-sm-3 Center-Stats-Col'>"
                + "<div class='card'>"
                 + "<div class='card-img-top'>"
                    + "<div class='alignImage' style='width: 120px;height: 120px;margin: auto;margin-top: 1vh;'>"
                     + "<div class='c100 " + toCssAmount((int)((pendindD / total) * 100)) + "'>"
                       + "<span>" + ((int)((pendindD / total) * 100)) + "%</span>"
                        + "<div class='slice'>"
                          + "<div class='bar'></div>"
                          + "<div class='fill'></div>"
                        + "</div>"
                      + "</div>"
                    + "</div>"
                 + "</div>"
                 + "<div class='card-title' style='width:fit-content;margin:auto;font-weight: bolder;'>Pending Delivery </div>"
                  + "<div class='card-body'>"
                    + "<p class='card-text' style='text-align: center;'>" + pendindD + "<span />/" + total + "</p>"
                  + "</div>"
                + "</div>"
              + "</div>";


            html += "<div class='col-sm-3 Center-Stats-Col'>"
                 + "<div class='card'>"
                  + "<div class='card-img-top'>"
                     + "<div class='alignImage' style='width: 120px;height: 120px;margin: auto;margin-top: 1vh;'>"
                      + "<div class='c100 " + toCssAmount((int)((completedO / total) * 100)) + "'>"
                       + "<span>" + ((int)((completedO / total) * 100)) + "%</span>"
                         + "<div class='slice'>"
                           + "<div class='bar'></div>"
                           + "<div class='fill'></div>"
                         + "</div>"
                       + "</div>"
                     + "</div>"
                  + "</div>"
                  + "<div class='card-title' style='width:fit-content;margin:auto;font-weight: bolder;'>Completed </div>"
                   + "<div class='card-body'>"
                     + "<p class='card-text' style='text-align: center;'>" + completedO + "<span />/"+total+"</p>"
                   + "</div>"
                 + "</div>"
               + "</div>";

            return html;
        }
        private string getUsersStats(List<User> users)
        {
            string html = "";
            double admins = users.Where(u => u.Type.Equals("Admin")).ToList<User>().Count;
            double drivers = users.Where(u => u.Type.Equals("Driver")).ToList<User>().Count;
            double customers = users.Where(u => u.Type.Equals("Customer")).ToList<User>().Count;
            double total = users.Count;
            html += "<div class='col-sm-3 Center-Stats-Col'>"
                + "<div class='card'>"
                 + "<div class='card-img-top'>"
                    + "<div class='alignImage' style='width: 120px;height: 120px;margin: auto;margin-top: 1vh;'>"
                      + "<div class='c100 " + toCssAmount((int)((customers / total) *100)) + "'>"
                       + "<span>" + ((int)((customers / total) * 100)) + "%</span>"
                        + "<div class='slice'>"
                          + "<div class='bar'></div>"
                          + "<div class='fill'></div>"
                        + "</div>"
                      + "</div>"
                    + "</div>"
                 + "</div>"
                 + "<div class='card-title' style='width:fit-content;margin:auto;font-weight: bolder;'>Customers </div>"
                  + "<div class='card-body'>"
                    + "<p class='card-text' style='text-align: center;'>" + customers + "<span />/" + total + "</p>"
                  + "</div>"
                + "</div>"
              + "</div>";

            html += "<div class='col-sm-3 Center-Stats-Col'>"
                + "<div class='card'>"
                 + "<div class='card-img-top'>"
                    + "<div class='alignImage' style='width: 120px;height: 120px;margin: auto;margin-top: 1vh;'>"
                      + "<div class='c100 " + toCssAmount((int)((drivers / total) * 100)) + "'>"
                       + "<span>" + ((int)((drivers / total) * 100)) + "%</span>"
                        + "<div class='slice'>"
                          + "<div class='bar'></div>"
                          + "<div class='fill'></div>"
                        + "</div>"
                      + "</div>"
                    + "</div>"
                 + "</div>"
                 + "<div class='card-title' style='width:fit-content;margin:auto;font-weight: bolder;'>Drivers </div>"
                  + "<div class='card-body'>"
                    + "<p class='card-text' style='text-align: center;'>" + drivers + "<span />/" + total + "</p>"
                  + "</div>"
                + "</div>"
              + "</div>";



            html += "<div class='col-sm-3 Center-Stats-Col'>"
                + "<div class='card'>"
                 + "<div class='card-img-top'>"
                    + "<div class='alignImage' style='width: 120px;height: 120px;margin: auto;margin-top: 1vh;'>"
                      + "<div class='c100 " + toCssAmount((int)((admins / total) * 100)) + "'>"
                       + "<span>" + ((int)((admins / total) * 100)) + "%</span>"
                        + "<div class='slice'>"
                          + "<div class='bar'></div>"
                          + "<div class='fill'></div>"
                        + "</div>"
                      + "</div>"
                    + "</div>"
                 + "</div>"
                 + "<div class='card-title' style='width:fit-content;margin:auto;font-weight: bolder;'>Admins </div>"
                  + "<div class='card-body'>"
                    + "<p class='card-text' style='text-align: center;'>" + admins + "<span />/" + total + "</p>"
                  + "</div>"
                + "</div>"
              + "</div>";

            return html;
        }
        private string toCssAmount(int value)
        {
            if (value < 10)
            {
                return "p0" + value;
            }
            else
            {
                return "p" + value;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string email = dDmail.Value.ToString();
            if(email.Length == 0)
            {
                lblResponse.Text = "Please enter user's email";
                return;
            }

            int status = new Client().UpdateType(email, "Driver").Result;
            if(status == 1)
            {
                lblResponse.Text = email+" has been updated to Driver";
            }
            else if(status == -2)
            {
                lblResponse.Text = "invalid request data";
            }
            else
            {
                lblResponse.Text = "an unexpected error occured";
            }
        }
    }
}