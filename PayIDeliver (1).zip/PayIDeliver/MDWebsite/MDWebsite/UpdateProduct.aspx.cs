﻿using MDWebsite.Api_Client;
using MDWebsite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MDWebsite
{
    public partial class UpdateProduct : System.Web.UI.Page
    {
        Meat meat = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                try
                {
                    int id = int.Parse(Request.QueryString["Id"]);
                    if (id > 0)
                    {
                        meat = new Client().GetProduct(id).Result;
                        if(meat != null)
                        {
                            UpdatePage();
                        }
                        else
                        {
                            Response.Redirect("Products.aspx");
                        }
                    }
                    else
                    {
                        Response.Redirect("Products.aspx");
                    }
                }
                catch(Exception ex)
                {
                    ex.GetBaseException();
                    Response.Redirect("Products.aspx");
                }
                
            }
        }
        private void UpdatePage()
        {
            txtName.Value = meat.Name;
            txtCategory.Value = meat.Category+"";
            txtWeight.Value = meat.Weight+"";
            txtQuantity.Value = meat.Quantity + "";
            txtPrice.Value = meat.Price + "";
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
            string validationResults = validateInputs();
            if (validationResults.Equals("pass"))
            {
                int id = int.Parse(Request.QueryString["Id"]);
                Meat dbMeat = new Client().GetProduct(id).Result;
                dbMeat = new Client().UpdateProduct(dbMeat).Result;
                if (dbMeat != null)
                {
                    dbMeat.Name = txtName.Value.ToString();
                    dbMeat.Weight = double.Parse(txtWeight.Value.ToString().Replace('.', ','));
                    dbMeat.Price = double.Parse(txtPrice.Value.ToString().Replace('.', ','));
                    dbMeat.Quantity = int.Parse(txtQuantity.Value.ToString().Replace('.', ','));

                    dbMeat = new Client().UpdateProduct(dbMeat).Result;
                    if(dbMeat != null)
                    {
                        Response.Redirect("Products.aspx");
                    }
                    else
                    {
                        lblRResponse.Text = "update failed, please try again later";
                    }
                }
                else
                {
                    lblRResponse.Text = "an uexpected error occured";
                }
            }
            else
            {
                lblRResponse.Text = validationResults;
            }
        }

        protected void BtnDelete_Click(object sender, EventArgs e)
        {
            int id = int.Parse(Request.QueryString["Id"]);
            Meat dbMeat = new Client().DeleteProduct(id).Result;
            if(dbMeat != null)
            {
                Response.Redirect("Products.aspx");
            }
            else
            {
                lblRResponse.Text = "failed to delete product";
            }
        }
        private string validateInputs()
        {
            if(!(txtName.Value.ToString().Length > 0) || !(txtWeight.Value.ToString().Length > 0) || !(txtPrice.Value.ToString().Length > 0) || !(txtQuantity.Value.ToString().Length > 0))
            {
                return "please fill in all fields";
            }
            try
            {
                double dc = int.Parse(txtName.Value.ToString().Replace('.', ','));
                return "Name field cannot be a number";
            }
            catch(Exception e)
            {
                e.GetBaseException();
            }

            try
            {
                double n = double.Parse(txtWeight.Value.ToString().Replace('.', ','));
            }
            catch(Exception e)
            {
                e.GetBaseException();
                return "Weight field must be a number";
            }
            try
            {
                double n = double.Parse(txtPrice.Value.ToString().Replace('.', ','));
            }
            catch (Exception e)
            {
                e.GetBaseException();
                return "Price field must be a number";
            }
            try
            {
                int n = int.Parse(txtQuantity.Value.ToString().Replace('.', ','));
            }
            catch (Exception e)
            {
                e.GetBaseException();
                return "Quantity field must be a number";
            }

            return "pass";
        }
    }
}