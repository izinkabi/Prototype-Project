﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MDWebApi.Models;
using MDWebApi.Lib;

namespace MDWebApi.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly ModelsContext _context;

        public UsersController(ModelsContext context)
        {
            _context = context;
        }

        // GET: api/Users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            try
            {
                return await _context.User.ToListAsync();
            }catch(Exception e)
            {
                e.GetBaseException();
                return new List<User>();
            }
        }

        // GET: api/Users/GetUser?id=idValue
        [HttpGet]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            try
            {
                var user = await _context.User.FindAsync(id);

                if (user == null)
                {
                    return NotFound("user not found");
                }

                return user;
            }catch(Exception e)
            {
                e.GetBaseException();
                return null;
            }
        }

        // PUT: api/Users/UpdateUser
        [HttpPut]
        public async Task<IActionResult> UpdateUser([FromBody]User user)
        {
            try
            {
                if (user == null)
                {
                    return BadRequest("user cannot be null");
                }

                _context.Entry(user).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(user.Id))
                {
                    return NotFound("user not found");
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Users/AddUser
        [HttpPost]
        public async Task<ActionResult<User>> AddUser([FromBody]User user)
        {
            try
            {
                if(ModelState.IsValid && user != null)
                {
                    user.Password = Security.HashSensitiveData(user.Password);//hash user password
                    user.Type = "Customer";
                    _context.User.Add(user);
                    await _context.SaveChangesAsync();

                    return CreatedAtAction("GetUser", new { id = user.Id }, user);
                }
                else
                {
                    return null;
                }
            }catch(Exception e)
            {
                e.GetBaseException();
                return null;
            }
        }

        // DELETE: api/Users/DeleteUser?id=idValue
        [HttpDelete]
        public async Task<ActionResult<User>> DeleteUser(int id)
        {
            var user = await _context.User.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            _context.User.Remove(user);
            await _context.SaveChangesAsync();

            return user;
        }

        private bool UserExists(int id)
        {
            try
            {
                return _context.User.Any(e => e.Id == id);
            }
            catch(Exception e)
            {
                e.GetBaseException();
                return false;
            }
        }
    }
}
