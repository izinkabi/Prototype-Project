﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MDWebApi.Lib;
using MDWebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MDWebApi.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class ServicesController : ControllerBase
    {
        private readonly ModelsContext _context;

        public ServicesController(ModelsContext context)
        {
            _context = context;
        }
        // GET: api/Services
        [HttpPost]
        public async Task<ActionResult<bool>> Login([FromBody] Access access)
        {
            if (ModelState.IsValid && access != null)
            {
                try
                {
                    User user = _context.User.Where(u => u.Email.Equals(access.Email)).FirstOrDefault<User>();
                    if(user != null)
                    {
                        if (Security.CompareHashedData(user.Password, access.Password))
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }catch(Exception e)
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        [HttpGet]
        public async Task<ActionResult<int>> UpdateType(string email,string type)
        {
            try
            {
                if(email.Length == 0){
                    return -2;
                }
                if(type.Length == 0)
                {
                    return -2;
                }
                User user = _context.User.Where(u => u.Email.Equals(email)).FirstOrDefault<User>();
                if(user == null)
                {
                    return -2;
                }
                if(type.Equals("Admin") || type.Equals("Customer") || type.Equals("Driver"))
                {
                    user.Type = type;
                    _context.User.Update(user);
                    _context.SaveChanges();
                    return 1;
                }
                else
                {
                    return -3;
                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
                return -1;
            }
        }
    }
}
