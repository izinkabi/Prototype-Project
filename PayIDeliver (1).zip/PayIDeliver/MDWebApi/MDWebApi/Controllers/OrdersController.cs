﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MDWebApi.Models;

namespace MDWebApi.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly ModelsContext _context;

        public OrdersController(ModelsContext context)
        {
            _context = context;
        }

        // GET: api/Orders
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Order>>> GetOrders()
        {
            return await _context.Order.ToListAsync();
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Order>>> GetPendingOrders()
        {
            return await _context.Order.Where(o => o.IsCompleted == false).ToListAsync();
        }
        [HttpGet]
        public async Task<ActionResult<int>> AssignOrder(string email,int orderId)
        {
            if(email.Length >0 && orderId > 0)
            {
                try
                {
                    User user = _context.User.Where(u => u.Email.Equals(email)).FirstOrDefault<User>();
                    Order order = _context.Order.Where(o => o.Id == orderId).FirstOrDefault<Order>();
                    if (user == null || order == null)
                    {
                        return -2;
                    }
                    order.DriverID = user.Id;
                    _context.Order.Update(order);
                    _context.SaveChanges();
                    return 1;
                }catch(Exception e)
                {
                    e.GetBaseException();
                    return -1;
                }
            }
            else
            {
                return -2;
            }
        }
        [HttpGet]
        public async Task<ActionResult<int>> UnAssignOrder(int id)
        {
            if (id > 0)
            {
                try
                {
                    Order order = _context.Order.Where(o => o.Id == id).FirstOrDefault<Order>();
                    if (order == null)
                    {
                        return -2;
                    }
                    order.DriverID = 0;
                    _context.Order.Update(order);
                    _context.SaveChanges();
                    return 1;
                }
                catch (Exception e)
                {
                    e.GetBaseException();
                    return -1;
                }
            }
            else
            {
                return -2;
            }
        }
        [HttpGet]
        public async Task<ActionResult<int>> CompleteOrder(int id)
        {
            if(id > 0)
            {
                try
                {
                    Order order = _context.Order.Where(o => o.Id == id).FirstOrDefault<Order>();
                    if(order  == null)
                    {
                        return -2;
                    }
                    order.IsCompleted = true;
                    _context.Order.Update(order);
                    _context.SaveChanges();
                    return 1;
                }catch(Exception e)
                {
                    e.GetBaseException();
                    return -1;
                }
            }
            else
            {
                return -2;
            }
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Order>>> GetUserOrders(int userId)
        {
            try
            {
                return _context.Order.Where(o => o.UserId == userId).ToList<Order>();
            }
            catch(Exception e)
            {
                e.GetBaseException();
                return new List<Order>();
            }
        }

        // GET: api/Orders/5
        [HttpGet]
        public async Task<ActionResult<Order>> GetOrder(int id)
        {
            try
            {
                var order = await _context.Order.FindAsync(id);

                if (order == null)
                {
                    return NotFound();
                }

                return order;
            }catch(Exception e)
            {
                e.GetBaseException();
                return null;
            }
        }

        // PUT: api/Orders/5
        [HttpPut]
        public async Task<ActionResult<Order>> UpdateOrder(Order order)
        {
            if(ModelState.IsValid  && order != null)
            {
                try
                {
                    _context.Entry(order).State = EntityState.Modified;
                    await _context.SaveChangesAsync();
                    return order;
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OrderExists(order.Id))
                    {
                        return null;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            else
            {
                return null;
            }
            
        }
        // POST: api/Orders
        [HttpPost]
        public async Task<ActionResult<Order>> AddOrder(Order order)
        {
            
            if(ModelState.IsValid && order != null)
            {
                try
                {
                    _context.Order.Add(order);
                    _context.SaveChanges();
                    return CreatedAtAction("GetOrder", new { id = order.Id }, order);
                }
                catch(Exception e)
                {
                    e.GetBaseException();
                    return null;
                }
            }
            else
            {
                return null;
            }
            
        }

        // DELETE: api/Orders/5
        [HttpDelete]
        public async Task<ActionResult<Order>> DeleteOrder(int id)
        {
            var order = await _context.Order.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }

            _context.Order.Remove(order);
            await _context.SaveChangesAsync();

            return order;
        }

        private bool OrderExists(int id)
        {
            return _context.Order.Any(e => e.Id == id);
        }
    }
}
