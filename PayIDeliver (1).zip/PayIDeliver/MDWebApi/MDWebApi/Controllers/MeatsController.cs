﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MDWebApi.Models;

namespace MDWebApi.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class MeatsController : ControllerBase
    {
        private readonly ModelsContext _context;

        public MeatsController(ModelsContext context)
        {
            _context = context;
        }

        // GET: api/Meats/GetMeats
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Meat>>> GetMeats()
        {
            return await _context.Meat.ToListAsync();
        }
        // GET: api/Meats/GetMeats?category=categoryValu
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Meat>>> GetMeatsByCategory(string category)
        {
            List<Meat> list = _context.Meat.Where(m => m.Category.Equals(category)).ToList<Meat>();
            return list;
        }
        [HttpPost]
        public async Task<ActionResult<IEnumerable<Meat>>> GetMeatsByIds([FromBody] List<int> IDs)
        {
            if(IDs == null)
            {
                return new List<Meat>();
            }
            try
            {
                List<Meat> products = new List<Meat>();
                for (int i = 0; i < IDs.Count; i++)
                {
                    Meat meat = _context.Meat.Where(m => m.Id == IDs.ElementAt(i)).FirstOrDefault<Meat>();
                    if(meat != null)
                    {
                        products.Add(meat);
                    }
                }
                return products;
            }catch(Exception e)
            {
                e.GetBaseException();
                return new List<Meat>();
            }
        }


        // GET: api/Meats/GetMeat?id=idValue
        [HttpGet]
        public async Task<ActionResult<Meat>> GetMeat(int id)
        {
            var meat = await _context.Meat.FindAsync(id);

            if (meat == null)
            {
                return NotFound();
            }

            return meat;
        }

        // PUT: api/Meats/UpdateMeat
        [HttpPost]
        public async Task<ActionResult<Meat>> UpdateMeat([FromBody] Meat meat)
        {
            if(ModelState.IsValid && meat != null)
            {
                try
                {
                    _context.Entry(meat).State = EntityState.Modified;
                    await _context.SaveChangesAsync();
                    return meat;
                }
                catch (DbUpdateConcurrencyException)
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
            
        }

        // POST: api/Meats/AddMeat
        [HttpPost]
        public async Task<ActionResult<Meat>> AddMeat([FromBody]Meat meat)
        {
            if(ModelState.IsValid && meat != null)
            {
                try
                {
                    _context.Meat.Add(meat);
                    await _context.SaveChangesAsync();

                    return CreatedAtAction("GetMeat", new { id = meat.Id }, meat);
                }
                catch(Exception e)
                {
                    e.GetBaseException();
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        // DELETE: api/Meats/DeleteMeat?id=idValue
        [HttpDelete]
        public async Task<ActionResult<Meat>> DeleteMeat(int id)
        {
            var meat = await _context.Meat.FindAsync(id);
            if (meat == null)
            {
                return null;
            }

            _context.Meat.Remove(meat);
            await _context.SaveChangesAsync();

            return meat;
        }

        private bool MeatExists(int id)
        {
            return _context.Meat.Any(e => e.Id == id);
        }
    }
}
