﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MDWebApi.Models;

namespace MDWebApi.Models
{
    public class ModelsContext : DbContext
    {
        public ModelsContext(DbContextOptions<ModelsContext> options)
        : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();
        }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<Meat> Meat { get; set; }
        public virtual DbSet<Order> Order { get; set; }
    }
}
