﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MDWebApi.Lib
{
    public class Access
    {
        public string Email { set; get; }
        public string Password { set; get; }
    }
}
