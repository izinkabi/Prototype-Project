﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MDWebApi.Models
{
    public class CartBP 
    {
        private User user;
        private List<Item> items;
        private double total;
        private string addressL1;
        private string addressL2;
        private string addressL3;
        private string addressL4;
        public CartBP(User user, List<Item> items, double total)
        {
            this.user = user;
            this.items = items;
            this.total = total;
        }
        public CartBP(List<Meat> meats,User user)
        {
            this.Items = new List<Item>();
            this.total = 0.0;
            this.user = user;
            for(int i = 0; i < meats.Count; i++)
            {
                Item item = new Item()
                {
                    Meat = meats.ElementAt(i),
                    Quantity = 1,
                    SubTotal = meats.ElementAt(i).Price
                };
                this.items.Add(item);
                this.total += item.SubTotal;
            }
        }
        public User User { get => user; set => user = value; }
        public List<Item> Items { get => items; set => items = value; }
        public double Total { get => total; set => total = value; }
        public string AddressL1 { get => addressL1; set => addressL1 = value; }
        public string AddressL2 { get => addressL2; set => addressL2 = value; }
        public string AddressL3 { get => addressL3; set => addressL3 = value; }
        public string AddressL4 { get => addressL4; set => addressL4 = value; }
        public void Remove(int id)
        {
            for(int i = 0;i< items.Count;i++)
            {
                if(items.ElementAt(i).Meat.Id == id)
                {
                    total -= items.ElementAt(i).SubTotal;
                    items.RemoveAt(i);
                }
            }
        }
        public bool Update(int id,int value)
        {
            for (int i = 0; i < items.Count; i++)
            {
                if (items.ElementAt(i).Meat.Id == id)
                {
                    if(items.ElementAt(i).Meat.Quantity >= value)
                    {
                        items.ElementAt(i).Quantity = value;
                        items.ElementAt(i).SubTotal = items.ElementAt(i).Meat.Price * value;
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        public void recalculateTotalAmount()
        {
            total = items.Sum(i => i.SubTotal);
        }
        public void setFullAddres(string l1,string l2, string l3,string l4)
        {
            addressL1 = l1;
            addressL2 = l2;
            addressL3 = l3;
            addressL4 = l4;
        }
    }
}