﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MDWebApi.Migrations
{
    public partial class updateUserTable2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<bool>(
                name: "IsActive",
                table: "User",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "IsActive",
                table: "User",
                nullable: true,
                oldClrType: typeof(bool));
        }
    }
}
