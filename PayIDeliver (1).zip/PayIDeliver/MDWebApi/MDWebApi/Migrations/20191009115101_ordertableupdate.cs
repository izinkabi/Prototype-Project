﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MDWebApi.Migrations
{
    public partial class ordertableupdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DriverID",
                table: "Order",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "IsCompleted",
                table: "Order",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DriverID",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "IsCompleted",
                table: "Order");
        }
    }
}
